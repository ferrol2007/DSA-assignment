class DynamicArray:
    def __init__(self):
        self.capacity = 2
        self.count = 0   # renamed 'size' to 'count'
        self.data = [None] * self.capacity

    def append(self, value):
        if self.count == self.capacity:
            self.capacity *= 2
            new_data = [None] * self.capacity
            for i in range(self.count):
                new_data[i] = self.data[i]
            self.data = new_data

        self.data[self.count] = value
        self.count += 1

    def pop(self):
        if self.count == 0:
            return None
        val = self.data[self.count - 1]
        self.count -= 1
        return val

    def print_array(self):
        print(self.data[:self.count])


class Node:
    def __init__(self, val):
        self.val = val   # renamed 'data' to 'val'
        self.next = None


class SinglyLinkedList:
    def __init__(self):
        self.head = None

    def insert_begin(self, value):
        new_node = Node(value)
        new_node.next = self.head
        self.head = new_node

    def insert_end(self, value):
        new_node = Node(value)
        if not self.head:
            self.head = new_node
            return
        temp = self.head
        while temp.next:
            temp = temp.next
        temp.next = new_node

    def delete(self, value):
        temp = self.head
        if temp and temp.val == value:
            self.head = temp.next
            return
        prev = None
        while temp and temp.val != value:
            prev = temp
            temp = temp.next
        if temp:
            prev.next = temp.next

    def traverse(self):
        temp = self.head
        while temp:
            print(temp.val, end=" -> ")
            temp = temp.next
        print("None")


class DNode:
    def __init__(self, val):
        self.val = val
        self.prev = None
        self.next = None


class DoublyLinkedList:
    def __init__(self):
        self.head = None

    def insert_end(self, value):
        new_node = DNode(value)
        if not self.head:
            self.head = new_node
            return
        temp = self.head
        while temp.next:
            temp = temp.next
        temp.next = new_node
        new_node.prev = temp

    def insert_after(self, target, value):
        temp = self.head
        while temp:
            if temp.val == target:
                new_node = DNode(value)
                new_node.next = temp.next
                new_node.prev = temp
                if temp.next:
                    temp.next.prev = new_node
                temp.next = new_node
                return
            temp = temp.next

    def delete_pos(self, pos):
        if not self.head:
            return
        temp = self.head

        if pos == 0:
            self.head = temp.next
            if self.head:
                self.head.prev = None
            return

        for _ in range(pos):
            if not temp:
                return
            temp = temp.next

        if not temp:
            return

        if temp.prev:
            temp.prev.next = temp.next
        if temp.next:
            temp.next.prev = temp.prev

    def traverse(self):
        temp = self.head
        while temp:
            print(temp.val, end=" <-> ")
            temp = temp.next
        print("None")


class Stack:
    def __init__(self):
        self.head = None

    def push(self, value):
        new_node = Node(value)
        new_node.next = self.head
        self.head = new_node

    def pop(self):
        if not self.head:
            return None
        val = self.head.val
        self.head = self.head.next
        return val

    def peek(self):
        return self.head.val if self.head else None


class Queue:
    def __init__(self):
        self.front_node = None
        self.rear = None

    def enqueue(self, value):
        new_node = Node(value)
        if not self.rear:
            self.front_node = self.rear = new_node
            return
        self.rear.next = new_node
        self.rear = new_node

    def dequeue(self):
        if not self.front_node:
            return None
        val = self.front_node.val
        self.front_node = self.front_node.next
        if not self.front_node:
            self.rear = None
        return val

    def front(self):
        return self.front_node.val if self.front_node else None


def is_balanced(expr):
    stack = Stack()
    pairs = {')': '(', '}': '{', ']': '['}

    for ch in expr:
        if ch in "({[":
            stack.push(ch)
        elif ch in ")}]":
            if not stack.head or stack.pop() != pairs[ch]:
                return False

    return stack.head is None


if __name__ == "__main__":

    print("Dynamic Array Demo:")
    da = DynamicArray()
    for i in range(10):
        da.append(i)
    da.print_array()
    print("Pop:", da.pop())
    da.print_array()

    print("\nSingly Linked List Demo:")
    sll = SinglyLinkedList()
    sll.insert_begin(1)
    sll.insert_end(2)
    sll.insert_end(3)
    sll.traverse()
    sll.delete(2)
    sll.traverse()

    print("\nDoubly Linked List Demo:")
    dll = DoublyLinkedList()
    dll.insert_end(10)
    dll.insert_end(20)
    dll.insert_end(30)
    dll.insert_after(20, 25)
    dll.traverse()
    dll.delete_pos(1)
    dll.traverse()

    print("\nStack Demo:")
    st = Stack()
    st.push(10)
    st.push(20)
    print("Pop:", st.pop())

    print("\nQueue Demo:")
    q = Queue()
    q.enqueue(1)
    q.enqueue(2)
    print("Dequeue:", q.dequeue())

    print("\nBalanced Expression Check:")
    print("([]):", is_balanced("([])"))
    print("([)]:", is_balanced("([)]"))
