class StackADT:
    def __init__(self):
        self.stack = []

    def push(self, x):
        self.stack.append(x)

    def pop(self):
        if not self.is_empty():
            return self.stack.pop()
        return None

    def peek(self):
        if not self.is_empty():
            return self.stack[-1]
        return None

    def is_empty(self):
        return len(self.stack) == 0

    def size(self):
        return len(self.stack)



def main():
    stack = StackADT()

    stack.push(10)
    stack.push(20)
    stack.push(30)

    print("Stack size:", stack.size())
    print("Top element:", stack.peek())

    print("Popped:", stack.pop())
    print("Popped:", stack.pop())

    print("Is stack empty?", stack.is_empty())
    print("Stack size:", stack.size())



if __name__ == "__main__":
    main()
