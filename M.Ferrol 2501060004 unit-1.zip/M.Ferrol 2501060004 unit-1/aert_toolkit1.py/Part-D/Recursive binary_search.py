def binary_search(arr, key, low, high):
    if low > high:
        return -1 
    mid = (low + high) // 2
    if arr[mid] == key:
        return mid
    elif arr[mid] > key:
        return binary_search(arr, key, low, mid - 1)
    else:
        return binary_search(arr, key, mid + 1, high)


def main():
    # Test Case 1
    arr = [1, 3, 5, 7, 9, 11, 13]
    print("Search 7:", binary_search(arr, 7, 0, len(arr)-1))   
    print("Search 1:", binary_search(arr, 1, 0, len(arr)-1))   
    print("Search 13:", binary_search(arr, 13, 0, len(arr)-1)) 
    print("Search 2:", binary_search(arr, 2, 0, len(arr)-1))   

   
    arr = []
    print("Search any key in empty list:", binary_search(arr, 5, 0, len(arr)-1))


if __name__ == "__main__":
    main()
