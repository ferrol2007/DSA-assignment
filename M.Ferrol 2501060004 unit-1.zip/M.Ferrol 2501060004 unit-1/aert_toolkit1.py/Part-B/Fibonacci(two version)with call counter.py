naive_calls = 0
memo_calls = 0

def fib_naive(n):
    global naive_calls
    naive_calls += 1
    if n <= 1:
        return n
    return fib_naive(n-1) + fib_naive(n-2)

def fib_memo(n, memo={}):
    global memo_calls
    memo_calls += 1
    if n in memo:
        return memo[n]
    if n <= 1:
        memo[n] = n
    else:
        memo[n] = fib_memo(n-1, memo) + fib_memo(n-2, memo)
    return memo[n]


def main():
    for n in [5, 10, 20, 30]:
        global naive_calls, memo_calls
        naive_calls, memo_calls = 0, 0
        print(f"\nFibonacci({n}):")
        print("Naive Result:", fib_naive(n), "| Calls:", naive_calls)

        naive_calls, memo_calls = 0, 0
        print("Memoized Result:", fib_memo(n), "| Calls:", memo_calls)


if __name__ == "__main__":
    main()
