def factorial(n):
    if n < 0:
        raise ValueError("n must be >= 0")
    if n == 0 or n == 1:
        return 1
    return n * factorial(n - 1)



def main():
    # Test cases
    print("Factorial(0):", factorial(0))
    print("Factorial(1):", factorial(1))
    print("Factorial(5):", factorial(5))
    print("Factorial(10):", factorial(10))



if __name__ == "__main__":
    main()
