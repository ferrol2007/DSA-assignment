def hanoi(n, source, auxiliary, destination):
    if n == 1:
        print(f"Move disk 1 from {source} to {destination}")
        return
    
   
    hanoi(n-1, source, destination, auxiliary)
    

    print(f"Move disk {n} from {source} to {destination}")
    

    hanoi(n-1, auxiliary, source, destination)


def main():
    print("=== Tower of Hanoi (N=3) ===")
    hanoi(3, "A", "B", "C")


if __name__ == "__main__":
    main()
