from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet

results = [
    (1000, "random", "Insertion Sort", 18.11),
    (1000, "random", "Merge Sort", 1.5),
    (1000, "random", "Quick Sort", 3.03),
    (1000, "sorted", "Insertion Sort", 0.09),
    (1000, "sorted", "Merge Sort", 1.29),
    (1000, "sorted", "Quick Sort", 0.86),
    (1000, "reversed", "Insertion Sort", 36.21),
    (1000, "reversed", "Merge Sort", 1.34),
    (1000, "reversed", "Quick Sort", 0.86),
    (5000, "random", "Insertion Sort", 487.16),
    (5000, "random", "Merge Sort", 10.25),
    (5000, "random", "Quick Sort", 8.11),
    (5000, "sorted", "Insertion Sort", 0.42),
    (5000, "sorted", "Merge Sort", 8.89),
    (5000, "sorted", "Quick Sort", 5.44),
    (5000, "reversed", "Insertion Sort", 912.82),
    (5000, "reversed", "Merge Sort", 8.03),
    (5000, "reversed", "Quick Sort", 5.36),
    (10000, "random", "Insertion Sort", 1807.71),
    (10000, "random", "Merge Sort", 19.5),
    (10000, "random", "Quick Sort", 29.18),
    (10000, "sorted", "Insertion Sort", 0.86),
    (10000, "sorted", "Merge Sort", 16.29),
    (10000, "sorted", "Quick Sort", 11.36),
    (10000, "reversed", "Insertion Sort", 3623.85),
    (10000, "reversed", "Merge Sort", 16.53),
    (10000, "reversed", "Quick Sort", 11.39),
]


doc = SimpleDocTemplate("report.pdf", pagesize=A4)
styles = getSampleStyleSheet()
story = []

story.append(Paragraph("Sorting Algorithms Analysis Report", styles['Title']))
story.append(Spacer(1, 12))


data = [["Size", "Type", "Algorithm", "Time (ms)"]] + results
table = Table(data, colWidths=[80, 100, 120, 80])
table.setStyle(TableStyle([
    ('BACKGROUND', (0,0), (-1,0), colors.grey),
    ('TEXTCOLOR',(0,0),(-1,0),colors.whitesmoke),
    ('ALIGN',(0,0),(-1,-1),'CENTER'),
    ('GRID', (0,0), (-1,-1), 1, colors.black),
]))
story.append(table)
story.append(Spacer(1, 24))


story.append(Paragraph("Random Input:", styles['Heading2']))
story.append(Paragraph("Insertion Sort grows quickly (O(n²)), while Merge Sort and Quick Sort remain efficient (O(n log n)).", styles['Normal']))
story.append(Spacer(1, 12))

story.append(Paragraph("Sorted Input:", styles['Heading2']))
story.append(Paragraph("Insertion Sort is very fast (almost linear). Merge Sort still runs in O(n log n). Quick Sort can degrade to O(n²) with poor pivot choice.", styles['Normal']))
story.append(Spacer(1, 12))

story.append(Paragraph("Reverse-Sorted Input:", styles['Heading2']))
story.append(Paragraph("Insertion Sort performs worst here. Merge Sort remains efficient. Quick Sort again risks poor pivot choices.", styles['Normal']))
story.append(Spacer(1, 12))


story.append(Paragraph("Complexity Discussion:", styles['Heading2']))
story.append(Paragraph("Theoretical O(n²) vs O(n log n) matches the timing results: Insertion Sort slows dramatically, while Merge Sort and Quick Sort scale better except in worst-case pivot scenarios.", styles['Normal']))
story.append(Spacer(1, 12))


story.append(Paragraph("Quick Sort Special Note:", styles['Heading2']))
story.append(Paragraph("Quick Sort’s worst case is O(n²) when pivot divides poorly (like sorted input with last-element pivot). This explains slow performance observed on sorted/reversed lists.", styles['Normal']))
story.append(Spacer(1, 12))

story.append(Paragraph("Stability and Memory Notes:", styles['Heading2']))
story.append(Paragraph("Insertion Sort: stable, in-place. Merge Sort: stable, out-of-place (extra space). Quick Sort: usually in-place, not stable.", styles['Normal']))

# Build PDF
doc.build(story)
print("report.pdf generated successfully!")