import random
import time


# (A) Timing Utility

def measure_time(sort_func, arr):
    data = arr.copy()
    start = time.time()
    sort_func(data)
    end = time.time()
    return (end - start) * 1000


# (B) Dataset Generator

def generate_datasets(sizes=[1000, 5000, 10000]):
    random.seed(42)
    datasets = {}
    for size in sizes:
        rand_list = [random.randint(1, 100000) for _ in range(size)]
        datasets[(size, "random")] = rand_list
        datasets[(size, "sorted")] = sorted(rand_list)
        datasets[(size, "reversed")] = sorted(rand_list, reverse=True)
    return datasets



# (C) Sorting Algorithms + Experiments

def insertion_sort(arr):
    for i in range(1, len(arr)):
        key = arr[i]
        j = i - 1
        while j >= 0 and arr[j] > key:
            arr[j+1] = arr[j]
            j -= 1
        arr[j+1] = key
    return arr

def merge_sort(arr):
    if len(arr) > 1:
        mid = len(arr)//2
        L = arr[:mid]
        R = arr[mid:]
        merge_sort(L)
        merge_sort(R)
        i = j = k = 0
        while i < len(L) and j < len(R):
            if L[i] < R[j]:
                arr[k] = L[i]; i += 1
            else:
                arr[k] = R[j]; j += 1
            k += 1
        while i < len(L):
            arr[k] = L[i]; i += 1; k += 1
        while j < len(R):
            arr[k] = R[j]; j += 1; k += 1
    return arr

def quick_sort(arr):
    if len(arr) <= 1:
        return arr
    pivot = arr[len(arr)//2]
    left = [x for x in arr if x < pivot]
    middle = [x for x in arr if x == pivot]
    right = [x for x in arr if x > pivot]
    return quick_sort(left) + middle + quick_sort(right)


def run_experiments():
    datasets = generate_datasets()
    results = []
    for (size, dtype), arr in datasets.items():
        for algo_name, algo_func in [
            ("Insertion Sort", insertion_sort),
            ("Merge Sort", merge_sort),
            ("Quick Sort", quick_sort)
        ]:
            t = measure_time(algo_func, arr)
            results.append((size, dtype, algo_name, round(t, 2)))
    return results



if __name__ == "__main__":
    results = run_experiments()
    print("Size | Type     | Algorithm       | Time (ms)")
    print("---------------------------------------------")
    for size, dtype, algo, t in results:
        print(f"{size:<5} | {dtype:<8} | {algo:<14} | {t}")

    import sys
    with open("output.txt", "w") as f:
        sys.stdout = f
        print("Size | Type     | Algorithm       | Time (ms)")
        print("---------------------------------------------")
        for size, dtype, algo, t in results:
            print(f"{size:<5} | {dtype:<8} | {algo:<14} | {t}")
