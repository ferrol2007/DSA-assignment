def partition(a, p, r):
    x = a[r]
    i = p - 1
    for j in range(p, r):
        if a[j] <= x:
            i += 1
            a[i], a[j] = a[j], a[i]
    a[i + 1], a[r] = a[r], a[i + 1]
    return i + 1
    
def quick_sort(a, p, r):
    if p < r:
        q = partition(a, p, r)
        quick_sort(a, p, q - 1)
        quick_sort(a, q + 1, r)
    return a
    
a = [10, 7, 8, 9, 1, 5]
print(f"Original array is: {a}")
n = len(a)
arr = quick_sort(a, 0, n - 1)
print("Sorted array is: ", arr)