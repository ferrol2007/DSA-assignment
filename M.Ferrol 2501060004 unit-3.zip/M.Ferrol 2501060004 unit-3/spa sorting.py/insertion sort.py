def insertion_sort(arr):
  
    for i in range(1,len(arr)):
        key=arr[i]  
        j = i - 1

     
        while j>=0  and arr[j]> key:
            arr[j+1]= arr[j]
            j=j-1

        
        arr[j+1]=key

    return arr
#Example usage
number=[12,11,13,5,3]
print("original:", number)
print("sorted:", insertion_sort(number))

